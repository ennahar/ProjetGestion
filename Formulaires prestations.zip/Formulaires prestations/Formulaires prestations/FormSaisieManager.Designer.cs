﻿namespace Formulaires_prestations
{
    partial class FormSaisieManager
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label1 = new System.Windows.Forms.Label();
            this.btnNouveau = new System.Windows.Forms.Button();
            this.btnValider = new System.Windows.Forms.Button();
            this.btnQuitter = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.TextCode = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.TextNom = new System.Windows.Forms.TextBox();
            this.TextPrenom = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.TextEmail = new System.Windows.Forms.TextBox();
            this.comboBoxListeService = new System.Windows.Forms.ComboBox();
            this.listeServicesBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.projetGestionDataSet1 = new Formulaires_prestations.ProjetGestionDataSet1();
            this.label6 = new System.Windows.Forms.Label();
            this.listeServicesTableAdapter = new Formulaires_prestations.ProjetGestionDataSet1TableAdapters.ListeServicesTableAdapter();
            ((System.ComponentModel.ISupportInitialize)(this.listeServicesBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.projetGestionDataSet1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F);
            this.label1.Location = new System.Drawing.Point(228, 21);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(368, 42);
            this.label1.TabIndex = 0;
            this.label1.Text = "Saisie des Managers";
            // 
            // btnNouveau
            // 
            this.btnNouveau.Location = new System.Drawing.Point(181, 131);
            this.btnNouveau.Name = "btnNouveau";
            this.btnNouveau.Size = new System.Drawing.Size(75, 23);
            this.btnNouveau.TabIndex = 1;
            this.btnNouveau.Text = "Nouveau";
            this.btnNouveau.UseVisualStyleBackColor = true;
            this.btnNouveau.Click += new System.EventHandler(this.btnNouveau_Click);
            // 
            // btnValider
            // 
            this.btnValider.Location = new System.Drawing.Point(402, 131);
            this.btnValider.Name = "btnValider";
            this.btnValider.Size = new System.Drawing.Size(75, 23);
            this.btnValider.TabIndex = 2;
            this.btnValider.Text = "Valider";
            this.btnValider.UseVisualStyleBackColor = true;
            this.btnValider.Click += new System.EventHandler(this.btnValider_Click);
            // 
            // btnQuitter
            // 
            this.btnQuitter.Location = new System.Drawing.Point(670, 131);
            this.btnQuitter.Name = "btnQuitter";
            this.btnQuitter.Size = new System.Drawing.Size(75, 23);
            this.btnQuitter.TabIndex = 3;
            this.btnQuitter.Text = "Quitter";
            this.btnQuitter.UseVisualStyleBackColor = true;
            this.btnQuitter.Click += new System.EventHandler(this.btnQuitter_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(32, 214);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(41, 13);
            this.label2.TabIndex = 4;
            this.label2.Text = "Code : ";
            // 
            // TextCode
            // 
            this.TextCode.Location = new System.Drawing.Point(190, 206);
            this.TextCode.MaxLength = 5;
            this.TextCode.Name = "TextCode";
            this.TextCode.Size = new System.Drawing.Size(37, 20);
            this.TextCode.TabIndex = 1;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(35, 251);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(35, 13);
            this.label3.TabIndex = 6;
            this.label3.Text = "Nom :";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(35, 282);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(52, 13);
            this.label4.TabIndex = 7;
            this.label4.Text = "Prenom : ";
            // 
            // TextNom
            // 
            this.TextNom.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.TextNom.Location = new System.Drawing.Point(190, 243);
            this.TextNom.MaxLength = 50;
            this.TextNom.Name = "TextNom";
            this.TextNom.Size = new System.Drawing.Size(287, 20);
            this.TextNom.TabIndex = 2;
            // 
            // TextPrenom
            // 
            this.TextPrenom.Location = new System.Drawing.Point(190, 275);
            this.TextPrenom.MaxLength = 50;
            this.TextPrenom.Name = "TextPrenom";
            this.TextPrenom.Size = new System.Drawing.Size(287, 20);
            this.TextPrenom.TabIndex = 3;
            this.TextPrenom.TextChanged += new System.EventHandler(this.textPrenom_TextChanged);
            this.TextPrenom.Validating += new System.ComponentModel.CancelEventHandler(this.textPrenom_validating);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(38, 326);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(40, 13);
            this.label5.TabIndex = 10;
            this.label5.Text = "email : ";
            // 
            // TextEmail
            // 
            this.TextEmail.Location = new System.Drawing.Point(190, 318);
            this.TextEmail.MaxLength = 100;
            this.TextEmail.Name = "TextEmail";
            this.TextEmail.Size = new System.Drawing.Size(527, 20);
            this.TextEmail.TabIndex = 4;
            this.TextEmail.TextChanged += new System.EventHandler(this.TextEmail_TextChanged);
            // 
            // comboBoxListeService
            // 
            this.comboBoxListeService.DataSource = this.listeServicesBindingSource;
            this.comboBoxListeService.DisplayMember = "s_desc";
            this.comboBoxListeService.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxListeService.FormattingEnabled = true;
            this.comboBoxListeService.Location = new System.Drawing.Point(190, 373);
            this.comboBoxListeService.Name = "comboBoxListeService";
            this.comboBoxListeService.Size = new System.Drawing.Size(198, 21);
            this.comboBoxListeService.TabIndex = 12;
            this.comboBoxListeService.ValueMember = "s_code";
            // 
            // listeServicesBindingSource
            // 
            this.listeServicesBindingSource.DataMember = "ListeServices";
            this.listeServicesBindingSource.DataSource = this.projetGestionDataSet1;
            // 
            // projetGestionDataSet1
            // 
            this.projetGestionDataSet1.DataSetName = "ProjetGestionDataSet1";
            this.projetGestionDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(41, 381);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(93, 13);
            this.label6.TabIndex = 13;
            this.label6.Text = "liste des services :";
            // 
            // listeServicesTableAdapter
            // 
            this.listeServicesTableAdapter.ClearBeforeFill = true;
            // 
            // FormSaisieManager
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(906, 588);
            this.ControlBox = false;
            this.Controls.Add(this.label6);
            this.Controls.Add(this.comboBoxListeService);
            this.Controls.Add(this.TextEmail);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.TextPrenom);
            this.Controls.Add(this.TextNom);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.TextCode);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.btnQuitter);
            this.Controls.Add(this.btnValider);
            this.Controls.Add(this.btnNouveau);
            this.Controls.Add(this.label1);
            this.Name = "FormSaisieManager";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "FormSaisieManager";
            this.Load += new System.EventHandler(this.FormSaisieManager_Load);
            ((System.ComponentModel.ISupportInitialize)(this.listeServicesBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.projetGestionDataSet1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnNouveau;
        private System.Windows.Forms.Button btnValider;
        private System.Windows.Forms.Button btnQuitter;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox TextCode;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox TextNom;
        private System.Windows.Forms.TextBox TextPrenom;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox TextEmail;
        private System.Windows.Forms.ComboBox comboBoxListeService;
        private System.Windows.Forms.Label label6;
        private ProjetGestionDataSet1 projetGestionDataSet1;
        private System.Windows.Forms.BindingSource listeServicesBindingSource;
        private ProjetGestionDataSet1TableAdapters.ListeServicesTableAdapter listeServicesTableAdapter;
    }
}