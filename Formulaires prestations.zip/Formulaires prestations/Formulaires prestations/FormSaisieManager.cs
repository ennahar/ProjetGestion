﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Formulaires_prestations
{
    public partial class FormSaisieManager : Form
    {
        public FormSaisieManager()
        {
            InitializeComponent();
            
        }

        private void btnNouveau_Click(object sender, EventArgs e)
        {
            TextCode.Clear();
            TextNom.Clear();
            TextPrenom.Clear();
            TextEmail.Clear();
        }

        private void textPrenom_validating(object sender, CancelEventArgs e)
        {
            if (TextPrenom.Text != "")
            {
                TextPrenom.Text = TextPrenom.Text.Substring(0, 1).ToUpper() + TextPrenom.Text.Substring(1).ToLower();
            }
        }

        private void textPrenom_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnValider_Click(object sender, EventArgs e)
        {
            if (TextNom.Text == "" || TextPrenom.Text == "")
            {
                MessageBox.Show("Saisie incorrecte, impossible de continuer...!");
                return;
            }
            if (TextEmail.Text != string.Empty)
            {
                bool resultat = false;
                Regex myRegex = new
                Regex(@"^([a-zA-Z0-9_\-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z0-9\-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$",
                RegexOptions.IgnoreCase);
                resultat = myRegex.IsMatch(TextEmail.Text);
                if (!resultat)
                {
                    MessageBox.Show("Adresse Email non valide....!");
                    return;
                }


            }
            else
            {
                MessageBox.Show("attention champ email vide !");
                return;
            }


            if (MessageBox.Show("Etes vous sure?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                try
                {   ///////// connexion à la base sql "ProjetGestion" /////////////
                    string sSQL;
                    string ChaineConnet = "data source=.\\SQLEXPRESS; integrated security=true;Initial catalog=ProjetGestion";
                    SqlConnection sqlconn = new SqlConnection(ChaineConnet);
                    //////// Ouverture de la connexion /////
                    sqlconn.Open();
                    ////// Requete à utiliser   //////////////              
                    sSQL = @"INSERT INTO Manager (m_code, m_nom, m_prenom, m_email,m_codeS) VALUES (@code,@nom,@prenom,@email,@codeS)";
                    SqlCommand cmd;
                    cmd = new SqlCommand(sSQL, sqlconn);
                    // Passage de parametres
                    cmd.Parameters.Add("@code",SqlDbType.VarChar,5);
                    cmd.Parameters.Add("@nom", SqlDbType.VarChar, 50);
                    cmd.Parameters.Add("@prenom", SqlDbType.VarChar, 50);
                    cmd.Parameters.Add("@email", SqlDbType.VarChar, 100);
                    cmd.Parameters.Add("@codeS", SqlDbType.VarChar, 5);

                    // affectation des valeurs///
                    cmd.Parameters["@code"].Value = TextCode.Text;
                    cmd.Parameters["@nom"].Value = TextNom.Text;
                    cmd.Parameters["@prenom"].Value = TextPrenom.Text;
                    cmd.Parameters["@email"].Value = TextEmail.Text;
                    cmd.Parameters["@CodeS"].Value = comboBoxListeService.Text.Substring(0, 5); //on recupere le 1er champ ( 0 à 5) qui correspond au code service


                    try
                    {
                        
                        ///// Executer la requete d insertion dans manager //////
                        cmd.ExecuteNonQuery();
                        MessageBox.Show("Manager ajouté...!");
                        TextCode.Text = "";
                        TextNom.Text = "";
                        TextPrenom.Text = "";
                        TextEmail.Text = "";
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex + "Erreur de mise à jour !", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        return;
                    }
                    sqlconn.Close();
                }
                catch
                {
                    MessageBox.Show("Erreur de connexion", "Attention", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
        }

        private void TextEmail_TextChanged(object sender, EventArgs e)
        {

        }

        private void FormSaisieManager_Load(object sender, EventArgs e)
        {
            // TODO: cette ligne de code charge les données dans la table 'projetGestionDataSet1.ListeServices'. Vous pouvez la déplacer ou la supprimer selon les besoins.
            this.listeServicesTableAdapter.Fill(this.projetGestionDataSet1.ListeServices);
           

        }
    }
}
