﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Formulaires_prestations
{
    public partial class Menu : Form
    {
        private int childFormNumber = 0;

        public Menu()
        {
            InitializeComponent();
        }

        private void ShowNewForm(object sender, EventArgs e)
        {
            Form childForm = new Form();
            childForm.MdiParent = this;
            childForm.Text = "Fenêtre " + childFormNumber++;
            childForm.Show();
        }

        private void OpenFile(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.Personal);
            openFileDialog.Filter = "Fichiers texte (*.txt)|*.txt|Tous les fichiers (*.*)|*.*";
            if (openFileDialog.ShowDialog(this) == DialogResult.OK)
            {
                string FileName = openFileDialog.FileName;
            }
        }

        private void SaveAsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SaveFileDialog saveFileDialog = new SaveFileDialog();
            saveFileDialog.InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.Personal);
            saveFileDialog.Filter = "Fichiers texte (*.txt)|*.txt|Tous les fichiers (*.*)|*.*";
            if (saveFileDialog.ShowDialog(this) == DialogResult.OK)
            {
                string FileName = saveFileDialog.FileName;
            }
        }

        private void ExitToolsStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void CutToolStripMenuItem_Click(object sender, EventArgs e)
        {
        }

        private void CopyToolStripMenuItem_Click(object sender, EventArgs e)
        {
        }

        private void PasteToolStripMenuItem_Click(object sender, EventArgs e)
        {
        }

        private void ToolBarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
        }

        private void StatusBarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
        }

        private void CascadeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LayoutMdi(MdiLayout.Cascade);
        }

        private void TileVerticalToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LayoutMdi(MdiLayout.TileVertical);
        }

        private void TileHorizontalToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LayoutMdi(MdiLayout.TileHorizontal);
        }

        private void ArrangeIconsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LayoutMdi(MdiLayout.ArrangeIcons);
        }

        private void CloseAllToolStripMenuItem_Click(object sender, EventArgs e)
        {
            foreach (Form childForm in MdiChildren)
            {
                childForm.Close();
            }
        }

        private void quitterToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Menu_Load(object sender, EventArgs e)
        {

        }

        private void saisiToolStripMenuItem_Click(object sender, EventArgs e)
        {
           
            FormSaisieUtilisateur Ma_FormSaisieUtilisateur = new FormSaisieUtilisateur();
            Ma_FormSaisieUtilisateur.Show();

    }

        private void saisieManagersToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormSaisieManager Ma_FormSaisieManager = new FormSaisieManager();
            Ma_FormSaisieManager.Show();
        }

        private void saisieProjetsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormSaisieProjet Ma_FormSaisieProjet = new FormSaisieProjet();
            Ma_FormSaisieProjet.Show();
        }

        private void saisieServicesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormSaisieService Ma_FormSaisieService = new FormSaisieService();
            Ma_FormSaisieService.Show();
        }

        private void saisieHeuresPrestésToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormSaisieJoursPrestees Ma_FormSaisieJoursPrestees = new FormSaisieJoursPrestees();
            Ma_FormSaisieJoursPrestees.Show();
        }

        private void listeDesServicesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormListService Ma_FormListService = new FormListService();
            Ma_FormListService.Show();
        }

        private void listeDesManagersToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormListManager Ma_FormListManager = new FormListManager();
            Ma_FormListManager.Show();
        }

        private void listeDesUtilisateursToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormListUtilisateur Ma_FormListUtilisateur = new FormListUtilisateur();
            Ma_FormListUtilisateur.Show();
        }

        private void listeDesProjetsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormListProjet Ma_FormListProjet = new FormListProjet();
            Ma_FormListProjet.Show();
        }
    }
}
