﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Formulaires_prestations
{
    public partial class FormSaisieJoursPrestees : Form
    {
        public FormSaisieJoursPrestees()
        {
            InitializeComponent();
            /////////////////////////////////////////////////////////////////////////////
            ///////connexion à la base sql "ProjetGestion"/////////////
            ///////////////////////////////////////////////////////////////////////////
            //string ChaineConnet = "data source=.\\SQLEXPRESS; integrated security=true;Initial catalog=ProjetGestion";
            //SqlConnection sqlconn = new SqlConnection(ChaineConnet);
            //sqlconn.Open(); //ouverture connexion////
            ////requete a utiliser pour remplissage de la combo liste des utilisateurs///
            ////////////////////////////////////////////////////////////////////////
            //string s2sql = @"select u_code , u_nom from Utilisateur";
            //SqlCommand cmd1;
            //cmd1 = new SqlCommand(s2sql, sqlconn);
            //SqlDataReader DataRead;
            //DataRead = cmd1.ExecuteReader();

            //while (DataRead.Read())
            //{

            //    comboBoxListUtilisateur.Items.Add(DataRead["u_code"].ToString()+" "+ DataRead["u_nom"]) ;

            //}
            //sqlconn.Close();//fermeture connexion////
            //sqlconn.Open();
            //string ssql = @"select p_code , p_desc from Projet";
            //SqlCommand cmd2;
            //cmd2 = new SqlCommand(ssql, sqlconn);
            //SqlDataReader DataRead1;
            //DataRead1 = cmd2.ExecuteReader();

            //while (DataRead1.Read())
            //{

            //    comboBoxNomProjet.Items.Add(DataRead1["p_code"].ToString()+" "+DataRead1["p_desc"].ToString());

            //}

            //sqlconn.Close();
        }

        private void btnValider_Click(object sender, EventArgs e)
        {
            string sSQL;
            string ChaineConnet = "data source=.\\SQLEXPRESS;integrated security=true;Initial catalog=ProjetGestion";
            SqlConnection sqlconn = new SqlConnection(ChaineConnet);
            sqlconn.Open();
            SqlCommand cmd;
            ///// Requete à utiliser pour verifier l existence de l enregistrement dans la table HP//////
            sSQL = @"select * from  HP where ( 
                                        hp_codeU=@code AND
                                        hp_date=@date AND
                                        hp_codeP=@codeP)";

            cmd = new SqlCommand(sSQL, sqlconn);
            // Passage de parametres//
            cmd.Parameters.Add("@code", SqlDbType.VarChar, 5);
            cmd.Parameters.Add("@codeP", SqlDbType.VarChar, 5);
            cmd.Parameters.Add("@tj", SqlDbType.Float);
            ////////////////////////////////
            /////affectation des valeurs ///
            cmd.Parameters["@code"].Value = comboBoxListUtilisateur.SelectedValue; //on recupere la valeur selectionnée dans la combo ListUtilisateur (qui est une vue sql avec un member value "codeU") ///
            cmd.Parameters["@codeP"].Value = comboBoxlistProjet.SelectedValue; //on recupere la valeur selectionnée dans la combo Listprojet (qui est une vue sql avec un member value "CodeP")///
            cmd.Parameters["@tj"].Value = comboBoxListTrancheJour.Text;
            cmd.Parameters.AddWithValue("@date", DateSaisieJP.Value.ToString("yyyy.MM.dd"));/////on affecte une date US a "hp_date" /////
            cmd.ExecuteNonQuery();
            ////////////////////////////
            SqlDataReader DataRead2;
            DataRead2 = cmd.ExecuteReader();
            bool trouvé = false;
            while (DataRead2.Read())
            {
                trouvé = true;
                break;
            }
            DataRead2.Close();
           
            if(!trouvé)
           {
                if (MessageBox.Show("Etes vous sure?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                    try
                    {

                        //////////////////////////////////////////////////////////////////
                        ////// Requete à utiliser pour insertion dans HP  //////////////              
                        sSQL = @"INSERT INTO HP (hp_date, hp_tj,hp_codeU,hp_codeP) VALUES (@date,@tj,@codeU,@codeP)";
                        
                        cmd = new SqlCommand(sSQL, sqlconn);
                        // Passage de parametres
                        //////////////////////////
                        cmd.Parameters.Add("@tj", SqlDbType.Float);
                        cmd.Parameters.Add("@codeU", SqlDbType.VarChar, 5);
                        cmd.Parameters.Add("@codeP", SqlDbType.VarChar, 5);

                        //affectation des valeurs////
                        ////////////////////////////                           
                        cmd.Parameters.AddWithValue("@date", DateSaisieJP.Value.ToString("yyyy.MM.dd"));
                        cmd.Parameters["@tj"].Value = comboBoxListTrancheJour.Text;
                        cmd.Parameters["@codeU"].Value = comboBoxListUtilisateur.SelectedValue;//on recupere la valeur selectionnée dans la combo ListUtilisateur (qui est une vue sql avec un member value "codeU") ///
                        cmd.Parameters["@codeP"].Value = comboBoxlistProjet.SelectedValue;//on recupere la valeur selectionnée dans la combo Listprojet (qui est une vue sql avec un member value "CodeP")///

                        try
                        {
                            ///// Executer la requete //////
                            cmd.ExecuteNonQuery();
                            MessageBox.Show("Heure prestée  ajouté...!");
                            DateSaisieJP.Text = "";
                            comboBoxListTrancheJour.Text = "";

                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show(ex + "Erreur de mise à jour !", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            return;
                        }
                       // sqlconn.Close();
                    }
                    catch
                    {
                        MessageBox.Show("Erreur de connexion", "Attention", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }

            }

        
            else ////enregistrement existe donc on update ////
            {
                if (MessageBox.Show("il y a deja un enregistrement Voulez-vous continuer ?", "Question", MessageBoxButtons.YesNo) == DialogResult.Yes)
                {
                    
                    sSQL = @"update HP SET hp_tj=@tj where ( 
                                        hp_codeU=@code AND
                                        hp_date=@date AND
                                        hp_codeP=@codeP)";
                    ///passage de parametres pour cmd/////
                    cmd = new SqlCommand(sSQL, sqlconn);
                    cmd.Parameters.Add("@code", SqlDbType.VarChar, 5);
                    cmd.Parameters.Add("@tj", SqlDbType.Float);
                    cmd.Parameters.Add("@codeP", SqlDbType.VarChar, 5);

                    //affectation des valeurs//// 
                    ////////////////////////////
                    cmd.Parameters["@code"].Value= comboBoxListUtilisateur.SelectedValue;
                    cmd.Parameters["@tj"].Value = comboBoxListTrancheJour.SelectedValue;
                    cmd.Parameters["@codeP"].Value = comboBoxlistProjet.SelectedValue;
                    ////////////////////////////////////////////////////////////////////////                 
                    ////////////////////////////////////////////////////////////////////////
                    ////requete s1SQL pour verifier si le tj < 1  pour un utilisateur donné////////////////////////////
                    string s1SQL = @"select hp_codeU, hp_date ,sum(hp_tj) as total_heures 
                                                        from HP
                                                        where  Hp_codeU=@code
                                                       group by hp_codeU,hp_date";

                    SqlCommand cmd1 = new SqlCommand(s1SQL, sqlconn);
                    string [] val = new string[1]; //tableau de string pour recup la resultat de la requete sql
                    //passage du parametre pour cmd1////
                    cmd1.Parameters.Add("@code", SqlDbType.VarChar, 5);
                    //affectation de la valeur//////
                    cmd1.Parameters["@code"].Value = comboBoxListUtilisateur.SelectedValue;
                    //on recupere la valeur selectionnée dans la combo ListUtilisateur (qui est une vue sql avec un member value "codeU") ///  
                   // cmd1.ExecuteNonQuery();
                    SqlDataReader DataRead3;
                    DataRead3 = cmd1.ExecuteReader(); 
                    while (DataRead3.Read())
                    {
                        val[0] = DataRead3["hp_codeU"].ToString();
                        
                    }
                   decimal CodeUT =Convert.ToDecimal(val[0]);
                   decimal Tranche_select = Convert.ToDecimal(comboBoxListTrancheJour.Text);
                   
                    if (CodeUT + Tranche_select > 1)  //test pour savoir si le total de tranche de journée depasse 1 ( qui represente une journée)
                    {    if (MessageBox.Show("attention la somme des heures prestées pour l'utilisateur :  "+ val[0]+ " depasse le maxi pour la journée : "+ DateSaisieJP.Text +" Voulez-vous continuer ?", "Question", MessageBoxButtons.YesNo) == DialogResult.Yes)
                        {
                            cmd.ExecuteNonQuery();
                            MessageBox.Show("Table heures Prestées mise à jour !");
                        }
                      

                    }

                  
                 
                 
                }
           }
        }

        private void FormSaisieJoursPrestees_Load(object sender, EventArgs e)
        {
            // TODO: cette ligne de code charge les données dans la table 'projetGestionDataSet3.ListeProjets'. Vous pouvez la déplacer ou la supprimer selon les besoins.
            this.listeProjetsTableAdapter.Fill(this.projetGestionDataSet3.ListeProjets);
            // TODO: cette ligne de code charge les données dans la table 'projetGestionDataSet2.ListeUtilisateurs'. Vous pouvez la déplacer ou la supprimer selon les besoins.
            this.listeUtilisateursTableAdapter.Fill(this.projetGestionDataSet2.ListeUtilisateurs);

        }
    }
    }


