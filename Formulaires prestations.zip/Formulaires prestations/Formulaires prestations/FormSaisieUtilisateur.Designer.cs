﻿namespace Formulaires_prestations
{
    partial class FormSaisieUtilisateur
    {
        /// <summary>
        /// Variable nécessaire au concepteur.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Nettoyage des ressources utilisées.
        /// </summary>
        /// <param name="disposing">true si les ressources managées doivent être supprimées ; sinon, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Code généré par le Concepteur Windows Form

        /// <summary>
        /// Méthode requise pour la prise en charge du concepteur - ne modifiez pas
        /// le contenu de cette méthode avec l'éditeur de code.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label1 = new System.Windows.Forms.Label();
            this.btnNouveau = new System.Windows.Forms.Button();
            this.btnValider = new System.Windows.Forms.Button();
            this.btnQuitter = new System.Windows.Forms.Button();
            this.textCode = new System.Windows.Forms.TextBox();
            this.textNom = new System.Windows.Forms.TextBox();
            this.textPrenom = new System.Windows.Forms.TextBox();
            this.textEmail = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.comboBoxListManager = new System.Windows.Forms.ComboBox();
            this.listeManagersBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.projetGestionDataSet = new Formulaires_prestations.ProjetGestionDataSet();
            this.listeManagersTableAdapter = new Formulaires_prestations.ProjetGestionDataSetTableAdapters.ListeManagersTableAdapter();
            this.listUtilisateurs = new System.Windows.Forms.ListView();
            ((System.ComponentModel.ISupportInitialize)(this.listeManagersBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.projetGestionDataSet)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.label1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(262, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(289, 42);
            this.label1.TabIndex = 0;
            this.label1.Text = "Saisie utilisateur";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // btnNouveau
            // 
            this.btnNouveau.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNouveau.Location = new System.Drawing.Point(75, 108);
            this.btnNouveau.Name = "btnNouveau";
            this.btnNouveau.Size = new System.Drawing.Size(75, 23);
            this.btnNouveau.TabIndex = 1;
            this.btnNouveau.Text = "nouveau";
            this.btnNouveau.UseVisualStyleBackColor = true;
            this.btnNouveau.Click += new System.EventHandler(this.btnNouveau_Click);
            // 
            // btnValider
            // 
            this.btnValider.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnValider.Location = new System.Drawing.Point(355, 108);
            this.btnValider.Name = "btnValider";
            this.btnValider.Size = new System.Drawing.Size(75, 23);
            this.btnValider.TabIndex = 2;
            this.btnValider.Text = "valider";
            this.btnValider.UseVisualStyleBackColor = true;
            this.btnValider.Click += new System.EventHandler(this.btnValider_Click);
            // 
            // btnQuitter
            // 
            this.btnQuitter.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnQuitter.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnQuitter.Location = new System.Drawing.Point(620, 108);
            this.btnQuitter.Name = "btnQuitter";
            this.btnQuitter.Size = new System.Drawing.Size(75, 23);
            this.btnQuitter.TabIndex = 3;
            this.btnQuitter.Text = "quitter";
            this.btnQuitter.UseVisualStyleBackColor = true;
            this.btnQuitter.Click += new System.EventHandler(this.btnQuitter_Click);
            // 
            // textCode
            // 
            this.textCode.Location = new System.Drawing.Point(213, 170);
            this.textCode.MaxLength = 5;
            this.textCode.Name = "textCode";
            this.textCode.Size = new System.Drawing.Size(35, 20);
            this.textCode.TabIndex = 1;
            this.textCode.Validating += new System.ComponentModel.CancelEventHandler(this.textCode_validating);
            // 
            // textNom
            // 
            this.textNom.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.textNom.Location = new System.Drawing.Point(213, 212);
            this.textNom.MaxLength = 50;
            this.textNom.Name = "textNom";
            this.textNom.Size = new System.Drawing.Size(323, 20);
            this.textNom.TabIndex = 2;
            this.textNom.TextChanged += new System.EventHandler(this.textNom_TextChanged);
            // 
            // textPrenom
            // 
            this.textPrenom.Location = new System.Drawing.Point(213, 248);
            this.textPrenom.MaxLength = 50;
            this.textPrenom.Name = "textPrenom";
            this.textPrenom.Size = new System.Drawing.Size(323, 20);
            this.textPrenom.TabIndex = 3;
            this.textPrenom.TextChanged += new System.EventHandler(this.textprenom_TextChanged);
            this.textPrenom.Validating += new System.ComponentModel.CancelEventHandler(this.textprenom_Validating);
            // 
            // textEmail
            // 
            this.textEmail.Location = new System.Drawing.Point(213, 286);
            this.textEmail.MaxLength = 100;
            this.textEmail.Name = "textEmail";
            this.textEmail.Size = new System.Drawing.Size(562, 20);
            this.textEmail.TabIndex = 4;
            this.textEmail.TextChanged += new System.EventHandler(this.textEmail_TextChanged);
            this.textEmail.Validating += new System.ComponentModel.CancelEventHandler(this.textEmail_validating);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(56, 176);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(47, 13);
            this.label2.TabIndex = 8;
            this.label2.Text = "code : ";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(56, 212);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(42, 13);
            this.label3.TabIndex = 9;
            this.label3.Text = "nom : ";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(56, 255);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(60, 13);
            this.label4.TabIndex = 10;
            this.label4.Text = "prenom : ";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(56, 293);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(48, 13);
            this.label5.TabIndex = 11;
            this.label5.Text = "email : ";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold);
            this.label6.Location = new System.Drawing.Point(59, 334);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(70, 13);
            this.label6.TabIndex = 12;
            this.label6.Text = "Managers :";
            // 
            // comboBoxListManager
            // 
            this.comboBoxListManager.DataBindings.Add(new System.Windows.Forms.Binding("SelectedValue", this.listeManagersBindingSource, "identite", true));
            this.comboBoxListManager.DataSource = this.listeManagersBindingSource;
            this.comboBoxListManager.DisplayMember = "identite";
            this.comboBoxListManager.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxListManager.FormattingEnabled = true;
            this.comboBoxListManager.Location = new System.Drawing.Point(213, 334);
            this.comboBoxListManager.Name = "comboBoxListManager";
            this.comboBoxListManager.Size = new System.Drawing.Size(121, 21);
            this.comboBoxListManager.TabIndex = 13;
            this.comboBoxListManager.ValueMember = "m_code";
            // 
            // listeManagersBindingSource
            // 
            this.listeManagersBindingSource.DataMember = "ListeManagers";
            this.listeManagersBindingSource.DataSource = this.projetGestionDataSet;
            // 
            // projetGestionDataSet
            // 
            this.projetGestionDataSet.DataSetName = "ProjetGestionDataSet";
            this.projetGestionDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // listeManagersTableAdapter
            // 
            this.listeManagersTableAdapter.ClearBeforeFill = true;
            // 
            // listUtilisateurs
            // 
            this.listUtilisateurs.Location = new System.Drawing.Point(185, 403);
            this.listUtilisateurs.Name = "listUtilisateurs";
            this.listUtilisateurs.Size = new System.Drawing.Size(590, 148);
            this.listUtilisateurs.TabIndex = 14;
            this.listUtilisateurs.UseCompatibleStateImageBehavior = false;
            this.listUtilisateurs.SelectedIndexChanged += new System.EventHandler(this.listUtilisateurs_SelectedIndexChanged);
            // 
            // FormSaisieUtilisateur
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(906, 588);
            this.ControlBox = false;
            this.Controls.Add(this.listUtilisateurs);
            this.Controls.Add(this.comboBoxListManager);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.textEmail);
            this.Controls.Add(this.textPrenom);
            this.Controls.Add(this.textNom);
            this.Controls.Add(this.textCode);
            this.Controls.Add(this.btnQuitter);
            this.Controls.Add(this.btnValider);
            this.Controls.Add(this.btnNouveau);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(2);
            this.MaximumSize = new System.Drawing.Size(922, 627);
            this.MinimumSize = new System.Drawing.Size(922, 627);
            this.Name = "FormSaisieUtilisateur";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "saisie utilisateur";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.listeManagersBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.projetGestionDataSet)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnNouveau;
        private System.Windows.Forms.Button btnValider;
        private System.Windows.Forms.Button btnQuitter;
        private System.Windows.Forms.TextBox textCode;
        private System.Windows.Forms.TextBox textNom;
        private System.Windows.Forms.TextBox textPrenom;
        private System.Windows.Forms.TextBox textEmail;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox comboBoxListManager;
        private ProjetGestionDataSet projetGestionDataSet;
        private System.Windows.Forms.BindingSource listeManagersBindingSource;
        private ProjetGestionDataSetTableAdapters.ListeManagersTableAdapter listeManagersTableAdapter;
        private System.Windows.Forms.ListView listUtilisateurs;
    }
}

