﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Formulaires_prestations
{
    public partial class FormListService : Form
    {
        public FormListService()
        {
            InitializeComponent();
            listService.Items.Clear();
            listService.View = View.Details;
            listService.AutoResizeColumns(ColumnHeaderAutoResizeStyle.ColumnContent); // pour avoir une + belle listview
            listService.AutoResizeColumns(ColumnHeaderAutoResizeStyle.HeaderSize);
            listService.Columns.Add("Code");
            listService.Columns.Add("Description");
           
        }

        private void FormListService_Load(object sender, EventArgs e)
        {
            string ChaineConnet = "data source=.\\SQLEXPRESS;integrated security=true;Initial catalog=ProjetGestion";
            SqlConnection sqlconn = new SqlConnection(ChaineConnet);
            SqlCommand cmd;
            string sSQL;

            sSQL = @"SELECT * FROM service";

            cmd = new SqlCommand(sSQL, sqlconn);

            string[] val = new string[2];
            ListViewItem itm;
            listService.Items.Clear();


            SqlDataReader DataRead;
            sqlconn.Open();
            DataRead = cmd.ExecuteReader();

            while (DataRead.Read())
            {
                val[0] = DataRead["s_code"].ToString();
                val[1] = DataRead["s_desc"].ToString();
                
                itm = new ListViewItem(val);
                listService.Items.Add(itm);
            }
            for (int ligne = 0; ligne < listService.Items.Count; ligne++)
            {
                if (ligne % 2 == 0) listService.Items[ligne].BackColor = Color.White;
                else listService.Items[ligne].BackColor = Color.LightPink;
            }
            sqlconn.Close();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
