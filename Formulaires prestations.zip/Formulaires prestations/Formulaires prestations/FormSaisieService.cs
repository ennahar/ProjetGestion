﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Formulaires_prestations
{
    public partial class FormSaisieService : Form
    {
        public FormSaisieService()
        {
            InitializeComponent();
            listService.View = View.Details;
            listService.Columns.Add("Code", 110);
            listService.Columns.Add("Description", 165);
            
        }

       
        private void btnValider_Click(object sender, EventArgs e)
        {
            
            if (TextBoxCode.Text == "" || TextBoxLibelle.Text =="" )
            {
                MessageBox.Show("Saisie incorrecte, impossible de continuer...!");
                return;
            }
            if (MessageBox.Show("Etes vous sure?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                try
                {
                    string sSQL;
                    string ChaineConnet = "data source=.\\SQLEXPRESS;integrated security=true;Initial catalog=ProjetGestion";
                    
                    SqlConnection sqlconn = new SqlConnection(ChaineConnet);
                    // Représente une connexion à une base de données SQL Server


                    // Ouverture de la connexion
                    sqlconn.Open();
                    // Requete à utiliser 
                    sSQL = @"INSERT INTO Service (s_code, s_desc) VALUES (@code,@desc)";
                    SqlCommand cmd;
                    cmd = new SqlCommand(sSQL, sqlconn);
                    // Passage de parametres
                    cmd.Parameters.Add("@code",SqlDbType.VarChar,5);
                    cmd.Parameters.Add("@desc", SqlDbType.VarChar,100);
                    //affectation des valeurs

                    cmd.Parameters["@code"].Value = TextBoxCode.Text;
                    cmd.Parameters["@desc"].Value = TextBoxLibelle.Text;
                    try
                    {
                        // Executer la requete
                        cmd.ExecuteNonQuery();
                        MessageBox.Show("Service ajouté...!");
                        TextBoxCode.Text = "";
                        TextBoxLibelle.Text = "";
                        
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex + "Erreur de mise à jours !", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        return;
                    }
                    sqlconn.Close();
                    string ChaineConnet1 = "data source=.\\SQLEXPRESS;integrated security=true;Initial catalog=ProjetGestion";
                    SqlConnection sqlconn1 = new SqlConnection(ChaineConnet1);
                    sqlconn1.Open();
                    SqlCommand cmd1;
                    string sSQL1;
                    sSQL1 = @"SELECT * FROM Service";
                    cmd1 = new SqlCommand(sSQL1, sqlconn1);
                    string[] val = new string[2];
                    ListViewItem itm;
                    listService.Items.Clear();
                    SqlDataReader DataRead;
                    DataRead = cmd1.ExecuteReader();

                    while (DataRead.Read())
                    {
                        val[0] = DataRead["s_code"].ToString();
                        val[1] = DataRead["s_desc"].ToString();

                        itm = new ListViewItem(val);
                        listService.Items.Add(itm);
                    }
                    sqlconn1.Close();
                }
                catch
                {
                    MessageBox.Show("Erreur de connexion", "Attention", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }

        }

        private void btnQuitter_Click(object sender, EventArgs e)
        {
            this.Close();
        }



        private void btnNouveau_Click(object sender, EventArgs e)
        {

        }

        private void listService_SelectedIndexChanged(object sender, EventArgs e)
        {
            var selectedItems = listService.SelectedItems;
            if (selectedItems.Count > 0)
            {
                TextBoxCode.Text = selectedItems[0].SubItems[0].Text;
                TextBoxLibelle.Text = selectedItems[0].SubItems[1].Text;
                
            }
        }

        private void FormSaisieService_Load(object sender, EventArgs e)
        {
            string ChaineConnet = "data source=.\\SQLEXPRESS;integrated security=true;Initial catalog=ProjetGestion";
            SqlConnection sqlconn = new SqlConnection(ChaineConnet);
            SqlCommand cmd;
            string sSQL;

            sSQL = @"SELECT * FROM Service";

            cmd = new SqlCommand(sSQL, sqlconn);

            string[] val = new string[2];
            ListViewItem itm;
            listService.Items.Clear();


            SqlDataReader DataRead;
            sqlconn.Open();
            DataRead = cmd.ExecuteReader();

            while (DataRead.Read())
            {
                val[0] = DataRead["s_code"].ToString();
                val[1] = DataRead["s_desc"].ToString();
                
                itm = new ListViewItem(val);
                listService.Items.Add(itm);
            }
            sqlconn.Close();
        }
    }
}
