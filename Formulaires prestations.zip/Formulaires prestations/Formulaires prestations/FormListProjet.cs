﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Formulaires_prestations
{
    public partial class FormListProjet : Form
    {
        public FormListProjet()
        {
            InitializeComponent();
            listProjet.Items.Clear();
            listProjet.View = View.Details;
            listProjet.AutoResizeColumns(ColumnHeaderAutoResizeStyle.ColumnContent); // pour avoir une + belle listview
            listProjet.AutoResizeColumns(ColumnHeaderAutoResizeStyle.HeaderSize);
            listProjet.Columns.Add("Code");
            listProjet.Columns.Add("Description");
            listProjet.Columns.Add("Date debut");
            listProjet.Columns.Add("Date fin");

        }

        private void FormListProjet_Load(object sender, EventArgs e)
        {
            string ChaineConnet = "data source=.\\SQLEXPRESS;integrated security=true;Initial catalog=ProjetGestion";
            SqlConnection sqlconn = new SqlConnection(ChaineConnet);
            SqlCommand cmd;
            string sSQL;

            sSQL = @"SELECT * FROM Projet";

            cmd = new SqlCommand(sSQL, sqlconn);

            string[] val = new string[4];
            ListViewItem itm;
            listProjet.Items.Clear();


            SqlDataReader DataRead;
            sqlconn.Open();
            DataRead = cmd.ExecuteReader();

            while (DataRead.Read())
            {
                val[0] = DataRead["p_code"].ToString();
                val[1] = DataRead["p_desc"].ToString();
                val[2] = DataRead["p_dated"].ToString();
                val[3] = DataRead["p_datef"].ToString();

                itm = new ListViewItem(val);
                listProjet.Items.Add(itm);
            }
            sqlconn.Close();
        }
    }
}
