﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Formulaires_prestations
{
    public partial class FormSaisieProjet : Form
    {
        public FormSaisieProjet()
        {
            InitializeComponent();
        }

        private void btnNouveau_Click(object sender, EventArgs e)
        {
            TextBoxCode.Clear();
            TextBoxLibelle.Clear();
            TextDescription.Clear();

        }

        private void TextCode_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnValider_Click(object sender, EventArgs e)
        {
            if (TextBoxCode.Text == "" || TextBoxLibelle.Text == "")
            {
                MessageBox.Show("Saisie incorrecte, impossible de continuer...!");
                return;
            }
            if (MessageBox.Show("Etes vous sure?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                try
                {
                    string sSQL;
                    string ChaineConnet = "data source=.\\SQLEXPRESS; integrated security=true;Initial catalog=ProjetGestion";

                    SqlConnection sqlconn = new SqlConnection(ChaineConnet);
                    /////////////////////////////////////////////////////////////////////////////
                    ///////Représente une connexion à une base de données SQL Server/////////////
                    ///////////////////////////////////////////////////////////////////////////

                    ////// Ouverture de la connexion /////
                    sqlconn.Open();
                    ////// Requete à utiliser   //////////////              
                   
                     sSQL = @"INSERT INTO Projet (p_code, p_desc,p_dated,p_datef) VALUES (@code,@libelle,@datedebut,@datefin)";
                    SqlCommand cmd;
                    cmd = new SqlCommand(sSQL, sqlconn);
                    // Passage de parametres
               
                    cmd.Parameters.Add("@code", SqlDbType.VarChar, 5);
                    cmd.Parameters.Add("@libelle", SqlDbType.VarChar, 100);
                    cmd.Parameters.Add("@datedebut", SqlDbType.Date);
                    cmd.Parameters.Add("@datefin", SqlDbType.Date);
                    
                    //Affectation des valeurs
                    cmd.Parameters["@code"].Value = TextBoxCode.Text;
                    cmd.Parameters["@libelle"].Value = TextBoxLibelle.Text;
                    cmd.Parameters["@datedebut"].Value = DateDebut.Text;
                    cmd.Parameters["@datefin"].Value = DateFin.Text;

                    try
                    {
                        ///// Executer la requete //////
                        cmd.ExecuteNonQuery();
                        MessageBox.Show("Projet ajouté...!");
                        TextBoxCode.Text = "";
                        TextBoxLibelle.Text = "";
                        
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex + "Erreur de mise à jour !", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        return;
                    }
                    sqlconn.Close();
                }
                catch
                {
                    MessageBox.Show("Erreur de connexion", "Attention", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
        }

        private void TextLibelle_TextChanged(object sender, EventArgs e)
        {

        }

        private void TextLibelle_validating(object sender, EventArgs e)
        {
            if (TextBoxLibelle.Text != "")
            {
                TextBoxLibelle.Text = TextBoxLibelle.Text.Substring(0, 1).ToUpper() + TextBoxLibelle.Text.Substring(1).ToLower();
            }
        }

        private void btnQuitter_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
