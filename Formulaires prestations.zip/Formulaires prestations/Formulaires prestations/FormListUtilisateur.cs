﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Formulaires_prestations
{
    public partial class FormListUtilisateur : Form
    {
        public FormListUtilisateur()
        {
            InitializeComponent();
            listUtilisateur.Items.Clear();
            listUtilisateur.View = View.Details;
            listUtilisateur.AutoResizeColumns(ColumnHeaderAutoResizeStyle.ColumnContent); // pour avoir une + belle listview
            listUtilisateur.AutoResizeColumns(ColumnHeaderAutoResizeStyle.HeaderSize);
            listUtilisateur.Columns.Add("Code");
            listUtilisateur.Columns.Add("Nom");
            listUtilisateur.Columns.Add("Prénom");
            listUtilisateur.Columns.Add("Email", 100);
        }

        private void FormListUtilisateur_Load(object sender, EventArgs e)
        {

            string ChaineConnet = "data source=.\\SQLEXPRESS;integrated security=true;Initial catalog=ProjetGestion";
            SqlConnection sqlconn = new SqlConnection(ChaineConnet);
            SqlCommand cmd;
            string sSQL;

            sSQL = @"SELECT * FROM Utilisateur";

            cmd = new SqlCommand(sSQL, sqlconn);

            string[] val = new string[4];
            ListViewItem itm;
            listUtilisateur.Items.Clear();


            SqlDataReader DataRead;
            sqlconn.Open();
            DataRead = cmd.ExecuteReader();

            while (DataRead.Read())
            {
                val[0] = DataRead["u_code"].ToString();
                val[1] = DataRead["u_nom"].ToString();
                val[2] = DataRead["u_prenom"].ToString();
                val[3] = DataRead["u_email"].ToString();
                itm = new ListViewItem(val);
                listUtilisateur.Items.Add(itm);
            }
            sqlconn.Close();
        }
    }
}
