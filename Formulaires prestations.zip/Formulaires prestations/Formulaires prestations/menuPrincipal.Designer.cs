﻿namespace Formulaires_prestations
{
    partial class Menu
    {
        /// <summary>
        /// Variable nécessaire au concepteur.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Nettoyage des ressources utilisées.
        /// </summary>
        /// <param name="disposing">true si les ressources managées doivent être supprimées ; sinon, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Code généré par le Concepteur Windows Form

        /// <summary>
        /// Méthode requise pour la prise en charge du concepteur - ne modifiez pas
        /// le contenu de cette méthode avec l'éditeur de code.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.menuStrip = new System.Windows.Forms.MenuStrip();
            this.fileMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.saisiToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saisieManagersToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saisieProjetsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saisieServicesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.editMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.saisieHeuresPrestésToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.viewMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.toolsMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.synchronisationToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.windowsMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.listeDesManagersToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.listeDesUtilisateursToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.listeDesProjetsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.listeDesServicesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.quitterToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.statusStrip = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolTip = new System.Windows.Forms.ToolTip(this.components);
            this.menuStrip.SuspendLayout();
            this.statusStrip.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip
            // 
            this.menuStrip.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileMenu,
            this.editMenu,
            this.viewMenu,
            this.toolsMenu,
            this.windowsMenu,
            this.quitterToolStripMenuItem});
            this.menuStrip.Location = new System.Drawing.Point(0, 0);
            this.menuStrip.MdiWindowListItem = this.windowsMenu;
            this.menuStrip.Name = "menuStrip";
            this.menuStrip.Size = new System.Drawing.Size(861, 24);
            this.menuStrip.TabIndex = 0;
            this.menuStrip.Text = "MenuStrip";
            // 
            // fileMenu
            // 
            this.fileMenu.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.saisiToolStripMenuItem,
            this.saisieManagersToolStripMenuItem,
            this.saisieProjetsToolStripMenuItem,
            this.saisieServicesToolStripMenuItem});
            this.fileMenu.ImageTransparentColor = System.Drawing.SystemColors.ActiveBorder;
            this.fileMenu.Name = "fileMenu";
            this.fileMenu.Size = new System.Drawing.Size(59, 20);
            this.fileMenu.Text = "Gestion";
            // 
            // saisiToolStripMenuItem
            // 
            this.saisiToolStripMenuItem.Name = "saisiToolStripMenuItem";
            this.saisiToolStripMenuItem.Size = new System.Drawing.Size(159, 22);
            this.saisiToolStripMenuItem.Text = "Saisie Utilisateur";
            this.saisiToolStripMenuItem.Click += new System.EventHandler(this.saisiToolStripMenuItem_Click);
            // 
            // saisieManagersToolStripMenuItem
            // 
            this.saisieManagersToolStripMenuItem.Name = "saisieManagersToolStripMenuItem";
            this.saisieManagersToolStripMenuItem.Size = new System.Drawing.Size(159, 22);
            this.saisieManagersToolStripMenuItem.Text = "Saisie Managers";
            this.saisieManagersToolStripMenuItem.Click += new System.EventHandler(this.saisieManagersToolStripMenuItem_Click);
            // 
            // saisieProjetsToolStripMenuItem
            // 
            this.saisieProjetsToolStripMenuItem.Name = "saisieProjetsToolStripMenuItem";
            this.saisieProjetsToolStripMenuItem.Size = new System.Drawing.Size(159, 22);
            this.saisieProjetsToolStripMenuItem.Text = "Saisie Projets";
            this.saisieProjetsToolStripMenuItem.Click += new System.EventHandler(this.saisieProjetsToolStripMenuItem_Click);
            // 
            // saisieServicesToolStripMenuItem
            // 
            this.saisieServicesToolStripMenuItem.Name = "saisieServicesToolStripMenuItem";
            this.saisieServicesToolStripMenuItem.Size = new System.Drawing.Size(159, 22);
            this.saisieServicesToolStripMenuItem.Text = "Saisie Services";
            this.saisieServicesToolStripMenuItem.Click += new System.EventHandler(this.saisieServicesToolStripMenuItem_Click);
            // 
            // editMenu
            // 
            this.editMenu.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.saisieHeuresPrestésToolStripMenuItem});
            this.editMenu.Name = "editMenu";
            this.editMenu.Size = new System.Drawing.Size(70, 20);
            this.editMenu.Text = "Saisie H.P";
            // 
            // saisieHeuresPrestésToolStripMenuItem
            // 
            this.saisieHeuresPrestésToolStripMenuItem.Name = "saisieHeuresPrestésToolStripMenuItem";
            this.saisieHeuresPrestésToolStripMenuItem.Size = new System.Drawing.Size(183, 22);
            this.saisieHeuresPrestésToolStripMenuItem.Text = "Saisie Heures prestés";
            this.saisieHeuresPrestésToolStripMenuItem.Click += new System.EventHandler(this.saisieHeuresPrestésToolStripMenuItem_Click);
            // 
            // viewMenu
            // 
            this.viewMenu.Name = "viewMenu";
            this.viewMenu.Size = new System.Drawing.Size(78, 20);
            this.viewMenu.Text = "Paramètres";
            // 
            // toolsMenu
            // 
            this.toolsMenu.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.synchronisationToolStripMenuItem});
            this.toolsMenu.Name = "toolsMenu";
            this.toolsMenu.Size = new System.Drawing.Size(68, 20);
            this.toolsMenu.Text = "Utilitaires";
            // 
            // synchronisationToolStripMenuItem
            // 
            this.synchronisationToolStripMenuItem.Name = "synchronisationToolStripMenuItem";
            this.synchronisationToolStripMenuItem.Size = new System.Drawing.Size(159, 22);
            this.synchronisationToolStripMenuItem.Text = "Synchronisation";
            // 
            // windowsMenu
            // 
            this.windowsMenu.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.listeDesManagersToolStripMenuItem,
            this.listeDesUtilisateursToolStripMenuItem,
            this.listeDesProjetsToolStripMenuItem,
            this.listeDesServicesToolStripMenuItem});
            this.windowsMenu.Name = "windowsMenu";
            this.windowsMenu.Size = new System.Drawing.Size(61, 20);
            this.windowsMenu.Text = "Editions";
            // 
            // listeDesManagersToolStripMenuItem
            // 
            this.listeDesManagersToolStripMenuItem.Name = "listeDesManagersToolStripMenuItem";
            this.listeDesManagersToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.listeDesManagersToolStripMenuItem.Text = "Liste des Managers";
            this.listeDesManagersToolStripMenuItem.Click += new System.EventHandler(this.listeDesManagersToolStripMenuItem_Click);
            // 
            // listeDesUtilisateursToolStripMenuItem
            // 
            this.listeDesUtilisateursToolStripMenuItem.Name = "listeDesUtilisateursToolStripMenuItem";
            this.listeDesUtilisateursToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.listeDesUtilisateursToolStripMenuItem.Text = "Liste des Utilisateurs";
            this.listeDesUtilisateursToolStripMenuItem.Click += new System.EventHandler(this.listeDesUtilisateursToolStripMenuItem_Click);
            // 
            // listeDesProjetsToolStripMenuItem
            // 
            this.listeDesProjetsToolStripMenuItem.Name = "listeDesProjetsToolStripMenuItem";
            this.listeDesProjetsToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.listeDesProjetsToolStripMenuItem.Text = "Liste des Projets";
            this.listeDesProjetsToolStripMenuItem.Click += new System.EventHandler(this.listeDesProjetsToolStripMenuItem_Click);
            // 
            // listeDesServicesToolStripMenuItem
            // 
            this.listeDesServicesToolStripMenuItem.Name = "listeDesServicesToolStripMenuItem";
            this.listeDesServicesToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.listeDesServicesToolStripMenuItem.Text = "Liste des Services";
            this.listeDesServicesToolStripMenuItem.Click += new System.EventHandler(this.listeDesServicesToolStripMenuItem_Click);
            // 
            // quitterToolStripMenuItem
            // 
            this.quitterToolStripMenuItem.Name = "quitterToolStripMenuItem";
            this.quitterToolStripMenuItem.Size = new System.Drawing.Size(56, 20);
            this.quitterToolStripMenuItem.Text = "Quitter";
            this.quitterToolStripMenuItem.Click += new System.EventHandler(this.quitterToolStripMenuItem_Click);
            // 
            // statusStrip
            // 
            this.statusStrip.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.statusStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel});
            this.statusStrip.Location = new System.Drawing.Point(0, 565);
            this.statusStrip.Name = "statusStrip";
            this.statusStrip.Size = new System.Drawing.Size(861, 22);
            this.statusStrip.TabIndex = 2;
            this.statusStrip.Text = "StatusStrip";
            // 
            // toolStripStatusLabel
            // 
            this.toolStripStatusLabel.Name = "toolStripStatusLabel";
            this.toolStripStatusLabel.Size = new System.Drawing.Size(27, 17);
            this.toolStripStatusLabel.Text = "État";
            // 
            // Menu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(861, 587);
            this.Controls.Add(this.statusStrip);
            this.Controls.Add(this.menuStrip);
            this.IsMdiContainer = true;
            this.MainMenuStrip = this.menuStrip;
            this.Name = "Menu";
            this.Text = "Menu";
            this.Load += new System.EventHandler(this.Menu_Load);
            this.menuStrip.ResumeLayout(false);
            this.menuStrip.PerformLayout();
            this.statusStrip.ResumeLayout(false);
            this.statusStrip.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }
        #endregion


        private System.Windows.Forms.MenuStrip menuStrip;
        private System.Windows.Forms.StatusStrip statusStrip;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel;
        private System.Windows.Forms.ToolStripMenuItem fileMenu;
        private System.Windows.Forms.ToolStripMenuItem editMenu;
        private System.Windows.Forms.ToolStripMenuItem viewMenu;
        private System.Windows.Forms.ToolStripMenuItem toolsMenu;
        private System.Windows.Forms.ToolStripMenuItem windowsMenu;
        private System.Windows.Forms.ToolTip toolTip;
        private System.Windows.Forms.ToolStripMenuItem saisieHeuresPrestésToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem synchronisationToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem quitterToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saisiToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saisieManagersToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saisieProjetsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem listeDesManagersToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem listeDesUtilisateursToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem listeDesProjetsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saisieServicesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem listeDesServicesToolStripMenuItem;
    }
}



