﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Formulaires_prestations
{
    public partial class FormListManager : Form
    {
        public FormListManager()
        {
            InitializeComponent();
            listManagers.Items.Clear();
            listManagers.View = View.Details;
            listManagers.AutoResizeColumns(ColumnHeaderAutoResizeStyle.ColumnContent); // pour avoir une + belle listview
            //listManagers.AutoResizeColumns(ColumnHeaderAutoResizeStyle.HeaderSize);
            listManagers.Columns.Add("Code");
            listManagers.Columns.Add("Nom");
            listManagers.Columns.Add("Prénom");
            listManagers.Columns.Add("Email");

        }

        private void FormListManager_Load(object sender, EventArgs e)
        {
            string ChaineConnet = "data source=.\\SQLEXPRESS;integrated security=true;Initial catalog=ProjetGestion";
            SqlConnection sqlconn = new SqlConnection(ChaineConnet);
            SqlCommand cmd;
            string sSQL;

            sSQL = @"SELECT * FROM Manager";

            cmd = new SqlCommand(sSQL, sqlconn);

            string[] val = new string[4];
            ListViewItem itm;
            listManagers.Items.Clear();


            SqlDataReader DataRead;
            sqlconn.Open();
            DataRead = cmd.ExecuteReader();

            while (DataRead.Read())
            {
                val[0] = DataRead["m_code"].ToString();
                val[1] = DataRead["m_nom"].ToString();
                val[2] = DataRead["m_prenom"].ToString();
                val[3] = DataRead["m_email"].ToString();
                itm = new ListViewItem(val);
                listManagers.Items.Add(itm);
            }
            sqlconn.Close();
        }
    }
}
