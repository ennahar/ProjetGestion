﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Formulaires_prestations
{
    public partial class FormSaisieUtilisateur : Form
    {
        public FormSaisieUtilisateur()
        {
            InitializeComponent();
            listUtilisateurs.View = View.Details;
            listUtilisateurs.Columns.Add("Code", 110);
            listUtilisateurs.Columns.Add("Nom", 165);
            listUtilisateurs.Columns.Add("Prénoms", 165);
            listUtilisateurs.Columns.Add("Email", 300);
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: cette ligne de code charge les données dans la table 'projetGestionDataSet.ListeManagers'. Vous pouvez la déplacer ou la supprimer selon les besoins.
            this.listeManagersTableAdapter.Fill(this.projetGestionDataSet.ListeManagers);
            string ChaineConnet = "data source=.\\SQLEXPRESS;integrated security=true;Initial catalog=ProjetGestion";
            SqlConnection sqlconn = new SqlConnection(ChaineConnet);
            SqlCommand cmd;
            string sSQL;

            sSQL = @"SELECT * FROM Utilisateur";

            cmd = new SqlCommand(sSQL, sqlconn);

            string[] val = new string[4];
            ListViewItem itm;
            listUtilisateurs.Items.Clear();


            SqlDataReader DataRead;
            sqlconn.Open();
            DataRead = cmd.ExecuteReader();

            while (DataRead.Read())
            {
                val[0] = DataRead["u_code"].ToString();
                val[1] = DataRead["u_nom"].ToString();
                val[2] = DataRead["u_prenom"].ToString();
                val[3] = DataRead["u_email"].ToString();
                itm = new ListViewItem(val);
                listUtilisateurs.Items.Add(itm);
            }
            sqlconn.Close();

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textCode_validating(object sender, EventArgs e)
        {

        }



        private void textNom_TextChanged(object sender, EventArgs e)
        {

        }

        private void textprenom_TextChanged(object sender, EventArgs e)
        {

        }

        private void textprenom_Validating(object sender, CancelEventArgs e)
        {
            if (textPrenom.Text != "")
            {
                textPrenom.Text = textPrenom.Text.Substring(0, 1).ToUpper() + textPrenom.Text.Substring(1).ToLower();
            }
        }

        private void textEmail_validating(object sender, CancelEventArgs e)
        {

        }

        private void textEmail_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnNouveau_Click(object sender, EventArgs e)
        {
            textCode.Clear();
            textNom.Clear();
            textPrenom.Clear();
            textEmail.Clear();

        }

        private void btnQuitter_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnValider_Click(object sender, EventArgs e)
        {
           

            if (textNom.Text == "" || textPrenom.Text == "")
            {
                MessageBox.Show("Saisie incorrecte, impossible de continuer...!");
                return;
            }
            if (textEmail.Text != string.Empty)
            {
                bool resultat = false;
                Regex myRegex = new
                Regex(@"^([a-zA-Z0-9_\-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z0-9\-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$",
                RegexOptions.IgnoreCase);
                resultat = myRegex.IsMatch(textEmail.Text);
                if (!resultat)
                {
                    MessageBox.Show("Adresse Email non valide....!");
                    return;
                }


            }


            if (MessageBox.Show("Etes vous sure?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                try
                {
                    string sSQL;
                    string ChaineConnet = "data source=.\\SQLEXPRESS; integrated security=true;Initial catalog=ProjetGestion";

                    SqlConnection sqlconn = new SqlConnection(ChaineConnet);
                    /////////////////////////////////////////////////////////////////////////////
                    ///////Représente une connexion à une base de données SQL Server/////////////
                    ///////////////////////////////////////////////////////////////////////////

                    ////// Ouverture de la connexion /////
                    sqlconn.Open();
                    ////// Requete à utiliser   //////////////              
                    sSQL = @"INSERT INTO Utilisateur (U_code, U_nom, U_prenom, U_email,u_codeM) VALUES (@code,@nom,@prenom,@email,@codeM)";
                    SqlCommand cmd;
                    cmd = new SqlCommand(sSQL, sqlconn);
                    // Passage de parametres
                    //////////////////////////
                    cmd.Parameters.Add("@code", SqlDbType.VarChar, 5);
                    cmd.Parameters.Add("@nom", SqlDbType.VarChar, 50);
                    cmd.Parameters.Add("@prenom", SqlDbType.VarChar, 50);
                    cmd.Parameters.Add("@email", SqlDbType.VarChar, 100);
                    cmd.Parameters.Add("@codeM", SqlDbType.VarChar,5);
                    //affectation des valeurs////
                    ////////////////////////////
                    cmd.Parameters["@code"].Value = textCode.Text;
                    cmd.Parameters["@nom"].Value = textNom.Text;
                    cmd.Parameters["@prenom"].Value = textPrenom.Text;
                    cmd.Parameters["@email"].Value = textEmail.Text;
                    cmd.Parameters["@codeM"].Value = comboBoxListManager.SelectedValue;

                    try
                    {
                        ///// Executer la requete //////
                        cmd.ExecuteNonQuery();
                        MessageBox.Show("Utilisateur ajouté...!");
                        textCode.Text = "";
                        textNom.Text = "";
                        textPrenom.Text = "";
                        textEmail.Text = "";
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex + "Erreur de mise à jour !", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        return;
                    }
                    sqlconn.Close();
                }
                catch
                {
                    MessageBox.Show("Erreur de connexion", "Attention", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
        }

        private void textCode_validating(object sender, CancelEventArgs e)
        {
            //if (textCode.Text.Length !=5)
            //{
            //    MessageBox.Show("5 caracteres obligatoires !");
            //}
        }

        private void listUtilisateurs_SelectedIndexChanged(object sender, EventArgs e)
        {
            var selectedItems = listUtilisateurs.SelectedItems;
            if (selectedItems.Count > 0)
            {
                textCode.Text = selectedItems[0].SubItems[0].Text;
                textNom.Text = selectedItems[0].SubItems[1].Text;
                textPrenom.Text = selectedItems[0].SubItems[2].Text;
                textEmail.Text = selectedItems[0].SubItems[3].Text;
            }
        }
    }
}
