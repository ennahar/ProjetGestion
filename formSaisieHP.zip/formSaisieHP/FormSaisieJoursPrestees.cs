﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Formulaires_prestations
{
    public partial class FormSaisieJoursPrestees : Form
    {
        public FormSaisieJoursPrestees()
        {
            InitializeComponent();
            /////////////////////////////////////////////////////////////////////////////
            ///////connexion à la base sql "ProjetGestion"/////////////
            ///////////////////////////////////////////////////////////////////////////
            string ChaineConnet = "data source=.\\SQLEXPRESS; integrated security=true;Initial catalog=ProjetGestion";
            SqlConnection sqlconn = new SqlConnection(ChaineConnet);
            sqlconn.Open(); //ouverture connexion////
            ////requete a utiliser pour remplissage de la combo liste des utilisateurs///
            ////////////////////////////////////////////////////////////////////////
            string s2sql = @"select u_code , u_nom from Utilisateur";
            SqlCommand cmd1;
            cmd1 = new SqlCommand(s2sql, sqlconn);
            SqlDataReader DataRead;
            DataRead = cmd1.ExecuteReader();

            while (DataRead.Read())
            {

                comboBoxListUtilisateur.Items.Add(DataRead["u_code"].ToString()+" "+ DataRead["u_nom"]) ;

            }
            sqlconn.Close();//fermeture connexion////
            sqlconn.Open();
            string ssql = @"select p_code , p_desc from Projet";
            SqlCommand cmd2;
            cmd2 = new SqlCommand(ssql, sqlconn);
            SqlDataReader DataRead1;
            DataRead1 = cmd2.ExecuteReader();

            while (DataRead1.Read())
            {

                comboBoxNomProjet.Items.Add(DataRead1["p_code"].ToString()+" "+DataRead1["p_desc"].ToString());

            }

            sqlconn.Close();
        }

        private void btnValider_Click(object sender, EventArgs e)
        {
            string sSQL;
            string ChaineConnet = "data source=.\\SQLEXPRESS;integrated security=true;Initial catalog=ProjetGestion";
            SqlConnection sqlconn = new SqlConnection(ChaineConnet);
            sqlconn.Open();
            SqlCommand cmd;
            //Représente une connexion à une base de données SQL Server
            // Ouverture de la connexion

            // Requete à utiliser pour verifier l existence de l enregistrement dans la table HP///
            sSQL = @"select * from  HP where ( 
                                        hp_codeU=@code AND
                                        hp_date=@date AND
                                        hp_codeP=@codeP)";

            cmd = new SqlCommand(sSQL, sqlconn);
            // Passage de parametres//
            cmd.Parameters.Add("@code", SqlDbType.VarChar, 5);
            cmd.Parameters.Add("@codeP", SqlDbType.VarChar, 5);
            cmd.Parameters.Add("@tj", SqlDbType.Float);
            ////////////////////////////////
            /////affectation des valeurs ///
            cmd.Parameters["@code"].Value = comboBoxListUtilisateur.Text.Substring(0, 5);
            cmd.Parameters["@codeP"].Value = comboBoxNomProjet.Text.Substring(0, 5);
            cmd.Parameters["@tj"].Value = comboBoxTrancheJour.Text;
            cmd.Parameters.AddWithValue("@date", DateSaisieJP.Value.ToString("yyyy.MM.dd"));//on affecte une date US a "hp_date" //
            cmd.ExecuteNonQuery();
            ////////////////////////////
            SqlDataReader DataRead2;
            DataRead2 = cmd.ExecuteReader();
            bool trouvé = false;
            while (DataRead2.Read())
            {
                trouvé = true;
                break;
            }
            DataRead2.Close();
            MessageBox.Show(trouvé.ToString());
            if(!trouvé)
           {
                if (MessageBox.Show("Etes vous sure?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                    try
                    {

                        //string ChaineConnet1 = "data source=.\\SQLEXPRESS;integrated security=true;Initial catalog=ProjetGestion";
                        // SqlConnection sqlconn1 = new SqlConnection(ChaineConnet1);
                        ////// Ouverture de la connexion /////
                        //sqlconn.Open();
                        ////// Requete à utiliser pour insertion dans HP  //////////////              
                        sSQL = @"INSERT INTO HP (hp_date, hp_tj,hp_codeU,hp_codeP) VALUES (@date,@tj,@codeU,@codeP)";
                        //SqlCommand cmd;
                        cmd = new SqlCommand(sSQL, sqlconn);
                      // Passage de parametres
                        //////////////////////////


                        cmd.Parameters.Add("@tj", SqlDbType.Float);
                        cmd.Parameters.Add("@codeU", SqlDbType.VarChar, 5);
                        cmd.Parameters.Add("@codeP", SqlDbType.VarChar, 5);

                        //affectation des valeurs////
                        ////////////////////////////

                        //cmd1.Parameters["@date"].Value = DateSaisieJP.Text;
                        cmd.Parameters.AddWithValue("@date", DateSaisieJP.Value.ToString("yyyy.MM.dd"));
                        cmd.Parameters["@tj"].Value = comboBoxTrancheJour.Text;
                        cmd.Parameters["@codeU"].Value = comboBoxListUtilisateur.Text.Substring(0, 5);
                        cmd.Parameters["@codeP"].Value = comboBoxNomProjet.Text.Substring(0, 5);

                        try
                        {
                            ///// Executer la requete //////
                            cmd.ExecuteNonQuery();
                            MessageBox.Show("Heure prestée  ajouté...!");
                            DateSaisieJP.Text = "";
                            comboBoxTrancheJour.Text = "";

                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show(ex + "Erreur de mise à jour !", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            return;
                        }
                       // sqlconn.Close();
                    }
                    catch
                    {
                        MessageBox.Show("Erreur de connexion", "Attention", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }

            }

        
            else
            {
                if (MessageBox.Show("il y a deja un enregistrement Voulez-vous continuer ?", "Question", MessageBoxButtons.YesNo) == DialogResult.Yes)
                {
                    
                    sSQL = @"update HP SET hp_tj=@tj where ( 
                                        hp_codeU=@code AND
                                        hp_date=@date AND
                                        hp_codeP=@codeP)";
                    //SqlCommand cmd1;
                    cmd = new SqlCommand(sSQL, sqlconn);
                    cmd.Parameters.Add("@code", SqlDbType.VarChar, 5);
                    cmd.Parameters.Add("@tj", SqlDbType.Float);
                    cmd.Parameters.Add("@codeU", SqlDbType.VarChar, 5);
                    cmd.Parameters.Add("@codeP", SqlDbType.VarChar, 5);

                    //affectation des valeurs////
                    ////////////////////////////

                    //cmd1.Parameters["@date"].Value = DateSaisieJP.Text;
                    cmd.Parameters.AddWithValue("@date", DateSaisieJP.Value.ToString("yyyy.MM.dd"));
                    cmd.Parameters["@tj"].Value = comboBoxTrancheJour.Text;
                    cmd.Parameters["@codeU"].Value = comboBoxListUtilisateur.Text.Substring(0, 5);
                    cmd.Parameters["@codeP"].Value = comboBoxNomProjet.Text.Substring(0, 5);
                    cmd.Parameters["@code"].Value = comboBoxListUtilisateur.Text.Substring(0, 5);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("ok");
                }
            }
            

        }
    }
    }


